export interface LeaveBalance{
    month:Date;
    year:Date;
    available:number;
    accured:number;
    consumed:number;
    balance:number;
}