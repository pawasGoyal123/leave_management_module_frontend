import { Component } from '@angular/core';

@Component({
  selector: 'app-leave-request-approval',
  standalone: true,
  imports: [],
  templateUrl: './leave-request-approval.component.html',
  styleUrl: './leave-request-approval.component.scss'
})
export class LeaveRequestApprovalComponent {

}
