import { Component } from '@angular/core';

@Component({
  selector: 'app-leave-request',
  standalone: true,
  imports: [],
  templateUrl: './leave-request.component.html',
  styleUrl: './leave-request.component.scss'
})
export class LeaveRequestComponent {

}
